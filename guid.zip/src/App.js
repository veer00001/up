import React from "react";
import Home from "./Component/Home";
import Header from "./Component/Header/Header";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Navabar from "./Component/Navbar/Navabar";
import MainForm from "./Component/MainForm/MainForm";
import Contactus from "./Component/ContactUs/Contactus";
import Career from "./Component/Career/Career";
import OutTestimonial from "./Component/Ourwork/OurTestimonail/OutTestimonial";
import Portfolio from "./Component/Ourwork/Portfolio/Portfolio";
import Aboutus from "./Component/Aboutus/Abous/Aboutus";
import OurTeam from "./Component/Aboutus/OurTeam/OurTeam";
import Awards from "./Component/Aboutus/Awards/Awards";
import WebsiteDesign from "./Component/WebsiteDesign/WebsiteDesign";
import SEO from './Component/Services/SEO/SEO'
import AppDevelopment from './Component/Services/AppDevelopment/AppDevelopment'





const App = () => {
  return (
    <BrowserRouter>
      <Header />
      <Navabar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/contactus" element={<Contactus />} />
        <Route path="/carrer" element={<Career />} />
        <Route path="/OurTestimonail" element={<OutTestimonial />} />
        <Route path="/Portfolio" element={<Portfolio />} />
        <Route path="/Abousus" element={<Aboutus />} />
        <Route path="/ourteam" element={<OurTeam />} />
        <Route path="/Awards" element={<Awards />} />
        <Route path="/WebsiteDesign" element={<WebsiteDesign />} />
        <Route path="/SEO" element={<SEO />} />
        <Route path="/AppDevelopment" element={<AppDevelopment />} />
      </Routes>
      <MainForm />
    </BrowserRouter>
  );
};

export default App;

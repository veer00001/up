import React from "react";
import "./Timeline.css";

const Timeline = () => {
  return (
    <div className="timelineParant">
      <div className="timeline">
        <div>
          <span className="firstLien"></span>
          <span className="circle" ></span>
          <span className="secondline"></span>
        </div>
        <div>
          <span className="firstLien"></span>
          <span className="circle"></span>
          <span className="secondline"></span>
        </div>
        <div>
          <span className="firstLien"></span>
          <span className="circle"></span>
          <span className="secondline"></span>
        </div>
        <div>
          <span className="firstLien"></span>
          <span className="circle"></span>
          <span className="secondline"></span>
        </div>
        <div>
          <span className="firstLien"></span>
          <span className="circle"></span>
          <span className="secondline"></span>
        </div>
        <div>
          <span className="firstLien"></span>
          <span className="circle"></span>
          <span className="secondline"></span>
        </div>
        <div>
          <span className="firstLien"></span>
          <span className="circle"></span>
          <span className="secondline"></span>
        </div>
        <div>
          <span className="firstLien"></span>
          <span className="circle"></span>
          <span className="secondline"></span>
        </div>
        <div>
          <span className="firstLien"></span>
          <span className="circle"></span>
          <span className="secondline"></span>
        </div>
        <div>
          <span className="firstLien"></span>
          <span className="circle"></span>
          <span className="secondline"></span>
        </div>
        <div>
          <span className="firstLien"></span>
          <span className="circle"></span>
          <span className="secondline"></span>
        </div>
      </div>
    </div>
  );
};

export default Timeline;

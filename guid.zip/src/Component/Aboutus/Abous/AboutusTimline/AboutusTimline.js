import React from "react";
import "./AboutusTimline.css";
import { MDBCard, MDBCardBody, MDBContainer } from "mdb-react-ui-kit";
import { MDBBtn, MDBCol, MDBRow, MDBTypography } from "mdb-react-ui-kit";

const AboutusTimline = () => {
  return (
    <div className="aboutusTImelineParant">
      <div className="headingprocess">
        <h2>Our Working Process</h2>
      </div>

      <div >
        <MDBContainer fluid className="py-5">
          <MDBRow>
            <MDBCol lg="12">
              <div className="horizontal-timeline">
                <MDBTypography listInLine className="items">
                  <li className="items-list">
                    <div className="px-4">
                      <div className="event-date badge bg-info">Step 1</div>
                      <h5 className="pt-2">Planning</h5>
                      <p className="text-muted">
                        It will be as simple as occidental in fact it will be
                        Occidental Cambridge friend
                      </p>
            
                    </div>
                  </li>
                  <li className="items-list">
                    <div className="px-4">
                      <div className="event-date badge bg-success">Step 2</div>
                      <h5 className="pt-2">Research</h5>
                      <p className="text-muted">
                        Everyone realizes why a new common language one could
                        refuse translators.
                      </p>
              
                    </div>
                  </li>
                  <li className="items-list">
                    <div className="px-4">
                      <div className="event-date badge bg-danger">Step 3</div>
                      <h5 className="pt-2">Optimizing</h5>
                      <p className="text-muted">
                        If several languages coalesce the grammar of the
                        resulting simple and regular
                      </p>
                      <div>
              
                      </div>
                    </div>
                  </li>
                  <li className="items-list">
                    <div className="px-4">
                      <div className="event-date badge bg-warning">Step 4</div>
                      <h5 className="pt-2">Result</h5>
                      <p className="text-muted">
                        Languages only differ in their pronunciation and their
                        most common words.
                      </p>
                      <div>
         
                      </div>
                    </div>
                  </li>
                </MDBTypography>
              </div>
            </MDBCol>
          </MDBRow>
        </MDBContainer>
      </div>

      <MDBContainer
        fluid
        className="py-5"
        style={{ backgroundColor: "#F0F2F5" }}
      >
        <div className="main-timeline">
          <div className="timeline left">
            <MDBCard>
              <MDBCardBody className="p-4">
                <h3>2024</h3>
                <p className="mb-0">
                  Lorem ipsum dolor sit amet, quo ei simul congue exerci, ad nec
                  admodum perfecto mnesarchum, vim ea mazim fierent detracto. Ea
                  quis iuvaret expetendis his, te elit voluptua dignissim per,
                  habeo iusto primis ea eam.
                </p>
              </MDBCardBody>
            </MDBCard>
          </div>
          <div className="timeline right">
            <MDBCard>
              <MDBCardBody className="p-4">
                <h3>2013</h3>
                <p className="mb-0">
                  Lorem ipsum dolor sit amet, quo ei simul congue exerci, ad nec
                  admodum perfecto mnesarchum, vim ea mazim fierent detracto. Ea
                  quis iuvaret expetendis his, te elit voluptua dignissim per,
                  habeo iusto primis ea eam.
                </p>
              </MDBCardBody>
            </MDBCard>
          </div>
          <div className="timeline left">
            <MDBCard>
              <MDBCardBody className="p-4">
                <h3>2022</h3>
                <p className="mb-0">
                  Lorem ipsum dolor sit amet, quo ei simul congue exerci, ad nec
                  admodum perfecto mnesarchum, vim ea mazim fierent detracto. Ea
                  quis iuvaret expetendis his, te elit voluptua dignissim per,
                  habeo iusto primis ea eam.
                </p>
              </MDBCardBody>
            </MDBCard>
          </div>
          <div className="timeline right">
            <MDBCard>
              <MDBCardBody className="p-4">
                <h3>2021</h3>
                <p className="mb-0">
                  Lorem ipsum dolor sit amet, quo ei simul congue exerci, ad nec
                  admodum perfecto mnesarchum, vim ea mazim fierent detracto. Ea
                  quis iuvaret expetendis his, te elit voluptua dignissim per,
                  habeo iusto primis ea eam.
                </p>
              </MDBCardBody>
            </MDBCard>
          </div>
          <div className="timeline left">
            <MDBCard>
              <MDBCardBody className="p-4">
                <h3>2020</h3>
                <p className="mb-0">
                  Lorem ipsum dolor sit amet, quo ei simul congue exerci, ad nec
                  admodum perfecto mnesarchum, vim ea mazim fierent detracto. Ea
                  quis iuvaret expetendis his, te elit voluptua dignissim per,
                  habeo iusto primis ea eam.
                </p>
              </MDBCardBody>
            </MDBCard>
          </div>
          <div className="timeline right">
            <MDBCard>
              <MDBCardBody className="p-4">
                <h3>2019</h3>
                <p className="mb-0">
                  Lorem ipsum dolor sit amet, quo ei simul congue exerci, ad nec
                  admodum perfecto mnesarchum, vim ea mazim fierent detracto. Ea
                  quis iuvaret expetendis his, te elit voluptua dignissim per,
                  habeo iusto primis ea eam.
                </p>
              </MDBCardBody>
            </MDBCard>
          </div>
          <div className="timeline left">
            <MDBCard>
              <MDBCardBody className="p-4">
                <h3>2018</h3>
                <p className="mb-0">
                  Lorem ipsum dolor sit amet, quo ei simul congue exerci, ad nec
                  admodum perfecto mnesarchum, vim ea mazim fierent detracto. Ea
                  quis iuvaret expetendis his, te elit voluptua dignissim per,
                  habeo iusto primis ea eam.
                </p>
              </MDBCardBody>
            </MDBCard>
          </div>
          <div className="timeline right">
            <MDBCard>
              <MDBCardBody className="p-4">
                <h3>2017</h3>
                <p className="mb-0">
                  Lorem ipsum dolor sit amet, quo ei simul congue exerci, ad nec
                  admodum perfecto mnesarchum, vim ea mazim fierent detracto. Ea
                  quis iuvaret expetendis his, te elit voluptua dignissim per,
                  habeo iusto primis ea eam.
                </p>
              </MDBCardBody>
            </MDBCard>
          </div>
          <div className="timeline left">
            <MDBCard>
              <MDBCardBody className="p-4">
                <h3>2016</h3>
                <p className="mb-0">
                  Lorem ipsum dolor sit amet, quo ei simul congue exerci, ad nec
                  admodum perfecto mnesarchum, vim ea mazim fierent detracto. Ea
                  quis iuvaret expetendis his, te elit voluptua dignissim per,
                  habeo iusto primis ea eam.
                </p>
              </MDBCardBody>
            </MDBCard>
          </div>
          <div className="timeline right">
            <MDBCard>
              <MDBCardBody className="p-4">
                <h3>2015</h3>
                <p className="mb-0">
                  Lorem ipsum dolor sit amet, quo ei simul congue exerci, ad nec
                  admodum perfecto mnesarchum, vim ea mazim fierent detracto. Ea
                  quis iuvaret expetendis his, te elit voluptua dignissim per,
                  habeo iusto primis ea eam.
                </p>
              </MDBCardBody>
            </MDBCard>
          </div>
          <div className="timeline left">
            <MDBCard>
              <MDBCardBody className="p-4">
                <h3>2014</h3>
                <p className="mb-0">
                  Lorem ipsum dolor sit amet, quo ei simul congue exerci, ad nec
                  admodum perfecto mnesarchum, vim ea mazim fierent detracto. Ea
                  quis iuvaret expetendis his, te elit voluptua dignissim per,
                  habeo iusto primis ea eam.
                </p>
              </MDBCardBody>
            </MDBCard>
          </div>
          <div className="timeline right">
            <MDBCard>
              <MDBCardBody className="p-4">
                <h3>2013</h3>
                <p className="mb-0">
                  Lorem ipsum dolor sit amet, quo ei simul congue exerci, ad nec
                  admodum perfecto mnesarchum, vim ea mazim fierent detracto. Ea
                  quis iuvaret expetendis his, te elit voluptua dignissim per,
                  habeo iusto primis ea eam.
                </p>
              </MDBCardBody>
            </MDBCard>
          </div>
        </div>
      </MDBContainer>
    </div>
  );
};

export default AboutusTimline;

import React from "react";
import "./Carousel.css";
import Carousel from "react-bootstrap/Carousel";
import Button from 'react-bootstrap/Button';
import {Link} from 'react-router-dom'

// import ExampleCarouselImage from "components/ExampleCarouselImage";

const MainBanner = () => {
  return (
    <div   className="mainBanner">
    <Carousel>
      <Carousel.Item interval={1000}>
        {/* <ExampleCarouselImage text="First slide" /> */}
        <img src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8V2ViJTIwZGVzaW5pbmd8ZW58MHx8MHx8fDA%3D"  className="bannerImages" alt="" />
        <Carousel.Caption>
          <h3>Software & Mobile Apps Development</h3>
          <p>Native mobile application development services for iOS, Android. 13+ Years Experience</p>
          <div className="banner-benifit">
            <li>Improve Brand Visibility </li>
            <li> Increase Quality Traffic</li>
            <li> Maximize ROI</li>
            <li> Fast Results</li>
          </div>
          <div className="banner-button-parant">

          <Button variant="primary"><Link to=""> Read More</Link></Button>{' '}
          <Button variant="primary"><Link to="">Get In Touch </Link></Button>{' '}
          </div>
        
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item interval={1000}>
        {/* <ExampleCarouselImage text="First slide" /> */}
        <img src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8V2ViJTIwZGVzaW5pbmd8ZW58MHx8MHx8fDA%3D"  className="bannerImages" alt="" />
        <Carousel.Caption>
          <h3>Get seen with SEO</h3>
          <p>Native mobile application development services for iOS, Android. 13+ Years Experience</p>
          <div className="banner-benifit">
            <li>Improve Brand Visibility </li>
            <li> Increase Quality Traffic</li>
            <li> Maximize ROI</li>
            <li> Fast Results</li>
          </div>
          <div className="banner-button-parant">

          <Button variant="primary"><Link to=""> Read More</Link></Button>{' '}
          <Button variant="primary"><Link to="">Get In Touch </Link></Button>{' '}
          </div>
        
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item interval={1000}>
        {/* <ExampleCarouselImage text="First slide" /> */}
        <img src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8V2ViJTIwZGVzaW5pbmd8ZW58MHx8MHx8fDA%3D"  className="bannerImages" alt="" />
        <Carousel.Caption>
          <h3>Best Social Media Marketing Agency</h3>
          <p>Native mobile application development services for iOS, Android. 13+ Years Experience</p>
          <div className="banner-benifit">
            <li>Improve Brand Visibility </li>
            <li> Increase Quality Traffic</li>
            <li> Maximize ROI</li>
            <li> Fast Results</li>
          </div>
          <div className="banner-button-parant">

          <Button variant="primary"><Link to=""> Read More</Link></Button>{' '}
          <Button variant="primary"><Link to="">Get In Touch </Link></Button>{' '}
          </div>
        
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item interval={1000}>
        {/* <ExampleCarouselImage text="First slide" /> */}
        <img src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8V2ViJTIwZGVzaW5pbmd8ZW58MHx8MHx8fDA%3D"  className="bannerImages" alt="" />
        <Carousel.Caption>
          <h3>Graphic Designing</h3>
          <p>Native mobile application development services for iOS, Android. 13+ Years Experience</p>
          <div className="banner-benifit">
            <li>Improve Brand Visibility </li>
            <li> Increase Quality Traffic</li>
            <li> Maximize ROI</li>
            <li> Fast Results</li>
          </div>
          <div className="banner-button-parant">

          <Button variant="primary"><Link to=""> Read More</Link></Button>{' '}
          <Button variant="primary"><Link to="">Get In Touch </Link></Button>{' '}
          </div>
        
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item interval={1000}>
        {/* <ExampleCarouselImage text="First slide" /> */}
        <img src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8V2ViJTIwZGVzaW5pbmd8ZW58MHx8MHx8fDA%3D"  className="bannerImages" alt="" />
        <Carousel.Caption>
          <h3>Web Apps Development</h3>
          <p>Native mobile application development services for iOS, Android. 13+ Years Experience</p>
          <div className="banner-benifit">
            <li>Improve Brand Visibility </li>
            <li> Increase Quality Traffic</li>
            <li> Maximize ROI</li>
            <li> Fast Results</li>
          </div>
          <div className="banner-button-parant">

          <Button variant="primary"><Link to=""> Read More</Link></Button>{' '}
          <Button variant="primary"><Link to="">Get In Touch </Link></Button>{' '}
          </div>
        
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item interval={1000}>
        {/* <ExampleCarouselImage text="First slide" /> */}
        <img src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8V2ViJTIwZGVzaW5pbmd8ZW58MHx8MHx8fDA%3D"  className="bannerImages" alt="" />
        <Carousel.Caption>
          <h3>Wordpress Development</h3>
          <p>Native mobile application development services for iOS, Android. 13+ Years Experience</p>
          <div className="banner-benifit">
            <li>Improve Brand Visibility </li>
            <li> Increase Quality Traffic</li>
            <li> Maximize ROI</li>
            <li> Fast Results</li>
          </div>
          <div className="banner-button-parant">

          <Button variant="primary"><Link to=""> Read More</Link></Button>{' '}
          <Button variant="primary"><Link to="">Get In Touch </Link></Button>{' '}
          </div>
        
        </Carousel.Caption>
      </Carousel.Item>
      
    </Carousel>
    </div>
  );
};

export default MainBanner;

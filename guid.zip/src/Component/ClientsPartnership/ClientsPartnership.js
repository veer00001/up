import React from "react";

import './ClientsPartnership.css'
import img from './WB/WB-1.jpg'

const ClientsPartnership = () => {
  return <> 
    <div className="ps-3 blue-line-bg">Give A Chance to add your logo with us</div>
  <div className="clientParterParant">
    
    <span className="wblogo"> <img src={img} alt=""/> </span>
    {/* <span className="plus">+=    </span> */}
    
 <img src=" data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAJQAqAMBIgACEQEDEQH/xAAbAAEAAgMBAQAAAAAAAAAAAAAABAUBAwYCB//EADwQAAIBAwMBBgMFBgQHAAAAAAECAwAEEQUSITEGEyJBUWFxgZEUMlKCoSNCYnKSsRUzQ8EkU6KjsuHx/8QAFwEBAQEBAAAAAAAAAAAAAAAAAAIBA//EAB8RAQADAAMBAAMBAAAAAAAAAAABAhESITFBE1FhA//aAAwDAQACEQMRAD8A+40pSgUpSgUpSgUpSgUpSgUpSgUpSgUpSgUpSgUpSgUpSgUpSgUpSgUpSgUpSgUpSgUpSgUpSgUpSgUpSgUpSgUpSgUpSgZpUW/F5sDWJhLg8pNkBvbI5H0NVp7Qi041mxubD1lI7yH+teg/mArcF5So9reW15EJbS4injPR4nDD6it+awZpSlAzSsGq2/1/SdOfZe6jbQyf8tpBv/pHNBZ0qhHa3SW5Vrpk/GtpKV+u2t9r2l0W6kEUOp23ek4EbuEY/JsGt42/Qt6V5VgenT1r1WBSleHkWNC8jBFUZJY4AoPdYyKon7T200hi0a3n1SQcE2oHdKfeQ4X6En2otnrl9zfX8VhEf9CxG5/nIw/so+Nbn7Zq4uLq3tVDXM8cQPQuwGa9xSLKgdCSp6ZBH96hWOjWNi3eQw7pj1nlYySt8XbJqeKxrNKUoFYY460PSqXX7lCUtTgsw37Cd24e6DqP5iF6ZNI7Em31OOQeMr0J3j7pGeo9vLPmelT1ZW6H2I9K5VHOQVZmLHcrKwJJA+9noxH4uEXoMmt0d4Y/uMMADxYbABPHuQT0/ec+i1WM1YXnZvSbmYzfZe4uD/rWztC/zKkZ+dRzpWs2uf8AD9daRfKO/t1lA/Mu1vqa9xahKgO7cSDtO7BORzt44LfiI8K/I1Ij1NOC4yCu4Y8x+Lnov8Rxny602TpDaftXEcfYtIuF/Et1JGT+UocfWvJbtbcZUR6PZA9HMkk5/pwo/WrOS5eUIbSaFcnOJUOX/l5H16VvgmY4WePupWBOzdu4HnmnL+GKQdmp7vnW9ZvrwHrFE32eP6Jgn61Y2WkaVpEJNlZW1si+JmVAPiSazqurW2mKne7nmlO2GCMbpJW9FH+/QedQUtJ7wfau0TRLF1jsVOY093P+o36DyB602ZOmf8bub47dBsvtKed3O/dwflOCzfIY96j3el69ejF3caHLH5xy6e7/AKmT/apM/aOxjwI3BJOPGwQfQ+I/JTW2PXbWSTYM5JAP8ORkZ9DjLY6gDnGRTv4zpSRaJ2i0yVJNHbTI1B/aQd5KsUg9AhDBPiuPnVp/iPaKPiXQYZfeC+XH/Uoq0iv7WQZEoU+jcHn/AOH6Uk1GzjUl7hAApY+fAOD+tOUz8MVDXnae68EGl2lgPOW6uO9x8FTr8yK9R9mIbmQS65dT6pIOQkx2wr8I14+uat0vrVzgTJxnrxSa+tolJeZOPQ58wP7kU2fjcbo4o4oxHEioi8BVGAK1zXMMJ2vIA3p1PUDp8x9aiC+a6k2WkTuoP+YTtXIz8+CuPnWyL7PZKQ5jVs87Rjrgc/oKzGt8FwZiNsUoX8TLj/3+lb6p59bRAO7QnPPi44wGPwON3zWmnX8txe7JXACgjAH3mzj9Cj/UUwXFKUrBg9K5TtfH3kiNIQUHCox4dvLAPBP5HPpXVnpVDq+i3t5K0ltqITI4imgynzKFWI9iSKqvUsnxyiTyxu4lcqFxJMp5ZfQvvPhA8jKQBgYj6YmxXjKVaUFAFMgUMVYjzYFsFR6zPgnooGaw+ha7a4xZ2dyqcq9tOEcH+GN07uP4jLe9QJ5WtQftun6jaeMNmaDvF3fjLAuDjrvlZsY4X169SjtaLexjDTKigKuyPaVREJ4JXqFJ+6n3pDg9MbZEcwk53OcOd2SGdnHXPkWHmfux9Oo4orWWC8UzWV3FOq7mLRT/ACZtx5Uc4Mr+PGQiitq74zg+BIwqsO7O1R+4vd9cfgi6sSGf0rOJq8R3JURjBkG7wliWHqeQzDy3uyg8YB4rVe6zeQPHYaZHE80qGTvCu5IEzjeVRfFzwAD1HJ4rxbyGWMZ3MxZs5IkJcfeJP3WYfvMfAh8IzWvULGHUpoWbf9qVcxzxO2/aeuOC0i+5Cr6elZGb23dbdKhXSrmfVbxp555ItheT9rK5BznC5ES+iD59K5+/1/UtZu+70y5Ux5yDuaPvfZQjbiPfOPKtknZ6O7lMd7dzXxjfKo2zMZ/lWUEH+YfKuq0TQokUO4fZ+F0RSfmvP61W1jtncufsOyWr3h7ybX9Tt4j1ESmPn2y5JHxFabrs/qHZ+IPaq9za4wYmbc4ycnYFAHJwTGo8QXG7HFfSgoAwAABwAKjzz2nefZZpYt8gx3TOMsD7VH5bSrjD5nD2ktHRcXUW4sqp3z7GU5zufOBncFJ92k8hkpu0Wn95tidXj2FcCUHKsu89M/vEL8qt9e7NGK+aWw7gvKC0sM3Czr59PuHGQWAAAOOpzWrR7bS7m4ksdRD2OouhXuplClskMdvOG5Abjpux5V12maidQ7W/1C/t17q3aHdEmWlBHi7znj4Cun0vRWmDzXrt3bPK3PG4P/YcCreKwsrJC5A2glgW6DPoK53tL2pht0kTvBHEjnqcb9mxvp4gK57y6rCvFtqOqiPdBYgBi2FcDw7mDH++OfU1TPcxMgM0u2A9SW6qRnPwxI3w7uqW2h17VhnT7KVYirhZZyYYwWk3AjOWOMelXdp2JllC/wCLak5UA/sLNe7XndxvPiPDsPLg1vGK+ybMq+41qCGQd8yiaTBZGPOMklMdTysq/mFXfZg3styLiawmSMLsSWb9nuGFBbafFk7QeQOpq50vQtL0of8AAWccTHlpDlnY+pY5JPxNWOBUWtHyGxE/QdBSs0qFFKUoFY5rNKCq1Ts/pWqMGvbGJ5QcrMo2SKfUMOQffNfO4ZNRisRdI32m03ShYZJMTQjewP7TOATwpJ8bZOMda+sEZqhuux+i3d09xNatl5O9eNZWWNn/ABFQcZ966UvnqLV3xzWi3UF/ayi1lJ7l17xRGd+FyAvdjjjB2x8qowzbiatguI2jkA2MS3dhu87webEkjecYyzEIOBziqlrC3k13VVJa2uLR1jgMJMYhgKLsxjhlJJ8AB3N1qTpWpQXd1Np93Kgv4nwEbbumwMg7QSCyg/5ecIRuPlVTG+MhaRGFogksrxrjEchdiOPwjwg/lUr/AGrNxcWMJwYpQPJpFmQn9MV5dHyxUkM+TlGbc+PcEM/xyqj4dYxAiUmBVjUnxSDaF+oCqT8HJ9an1WvI1Bt+22unVR6tIf8AywtRru9uLaEzTy3JDNgBpoxn+gGtk8kwj3LKGHqsUkin/ukVzd5dpJM0RNvvXkojJA3xxyautdTMuj0zUbe6jV7KRTv8TMxXfkHgkEDkeRKt8K36hBb39ubS/thPbg+KJ0O7nzweQTkgZ8TM2eAK5OJBJKZYp54J+CXS4Z1mx0EgUZYD0yKsUv7q2jU3kLpGjbVeAK6Fm4BwmGjBJx9zdzjdzWzTPCJa7u01G2vLeyjvVeyupFhFzMN7QEsSFJ4LgspwevOT1Fdlo/ZPTdMmN0yG6vWYu9zcYLbickgdF59BXOaVY3OsajZkW11FZ28iyzTXEHc94VOQqofUqnsqooGTmvoVRe0+NiGBSs0rkspSlApSlApSlApSlApSlBR9pOz1pq9vJL3ONQSFlt51kaNlbBwCVI4z61wveaSumJpc1s9teDGbd43WVXGCXyoyeclQn3jyW5OPq1YOfKrreY6TNdfKNP1+8ntUfUzdQortGt3NAAkhXPLKOrjoFOI1PqRVxctMIoyLo/tAdkkbl3lH8LL43/L3aDPWrCXsvqds1xHpd7aNZzM7dxdwsxXcSdu5SMpknwn15zUOx7EajZQTNHqdsZZcF7c25NvIck5ZSeuTnjC/w10m1Z7TkqOa4thmWdJktwVX7XIqSRlz+6GUP9S9Zu1Qldx90liMSkfBlfOParaew1dJ1aTQppLgeENDdRsjj3kbDgfwgKPjVhY9iVitIm+3XdneEs8q2kx7jcxzgI2RgdB06c1XOsM4zLmbWC8M9rF3FtqTThtggmaCUbeSW2vt+mKv9N0rUr6a2iurF7GwhlWaQTXLSvIyHKqoLHAzgk+1XujdnotNu2vJbq5vLpk2CSdhiNepCqAAM4GfXFXVc7/6b4qKsYBr1SlcllKUoFKUoFKUoFKUoFKUoFKUoFKUoFKUoMYrNKUClKUClKUClKUClKUClKUClKUClKUClKUClKUClKUClKUClKUClKUClKUClKUClKUClKUClKUClKUClKUClKUClKUClKUClKUClKUClKUClKUH/9k="   width="50vw"  style={{width:"10vw"}}  />  
    <div className="parterns-images">
         <span>  <img src="https://www.webbraininfotech.com/img/client-logo.png"  /> </span>
         <span>  <img src="https://www.webbraininfotech.com/img/client-logo1.png"  /> </span>
         <span>  <img src="https://www.webbraininfotech.com/img/client-logo2.png"  /> </span>
         <span>  <img src="https://www.webbraininfotech.com/img/client-logo3.png"  /> </span>
         <span>  <img src="https://www.webbraininfotech.com/img/client-logo4.png"  /> </span>
         <span>  <img src="https://www.webbraininfotech.com/img/client-logo5.png"  /> </span>
         <span>  <img src="https://www.webbraininfotech.com/img/client-logo6.png"  /> </span>
         <span>  <img src="https://www.webbraininfotech.com/img/client-logo7.png"  /> </span>
         <span>  <img src="https://www.webbraininfotech.com/img/client-logo8.png"  /> </span>
         <span>  <img src="https://www.webbraininfotech.com/img/client-logo9.png"  /> </span>
         <span>  <img src="https://www.webbraininfotech.com/img/client-logo10.png"  /> </span>
         <span>  <img src="https://www.webbraininfotech.com/img/client-logo11.png"  /> </span>
         <span>  <img src="https://www.webbraininfotech.com/img/client-logo12.png"  /> </span>
    </div>
  </div>
  </>
};

export default ClientsPartnership;

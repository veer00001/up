import React from "react";
import "./ContactUs.css";
import { Link } from "react-router-dom";

const Contactus = () => {
  return (
    <div className="ContactUsParant">
      <div class="contain">
        <div class="wrapper">
          <div class="form">
            <h2 class="form-headline">Send us a message</h2>
          </div>
        </div>

        <div className="contactUs">
          <div className="">
            <Link to="">sales@webbraininfotech.com</Link>
            <Link to="">+91 11 47051378</Link>
            <Link to="">+91-782-774-2414</Link>
            <Link to="">+91-782-774-2414</Link>
          </div>

          <div>
            <Link to="">info@webbraininfotech.com</Link>
            <Link to="">+91 11 45086414</Link>
            <Link to="">+91-11-470-51-378</Link>
            <Link to="">+91-782-774-2414</Link>
          </div>

          <div>
            <Link to="">hr@webbraininfotech.com</Link>
            <Link to="">+91 11 42953020</Link>
            <Link to="">+91-11-450-86-414</Link>
            <Link to="">+91-782-774-2414</Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contactus;

import React from "react";
import "./HomeTab.css";
import Col from "react-bootstrap/Col";
import Nav from "react-bootstrap/Nav";
import Row from "react-bootstrap/Row";
import Tab from "react-bootstrap/Tab";
import { Link } from "react-router-dom";

const HomeTab = () => {
  return (
    <div className="homeTab-parant">
      <Tab.Container id="left-tabs-example" defaultActiveKey="first">
        <Row>
          <Col sm={3} className="tabHeading">
            <Nav variant="pills" className="flex-column">
              <Nav.Item>
                <Nav.Link eventKey="first"> Website Design</Nav.Link>
              </Nav.Item>
              <Nav.Item>
                <Nav.Link eventKey="second">Website Development</Nav.Link>
              </Nav.Item>
              <Nav.Item>
                <Nav.Link eventKey="Thrid">Wordpress Development</Nav.Link>
              </Nav.Item>
              <Nav.Item>
                <Nav.Link eventKey="Fourth">Mobile App Development</Nav.Link>
              </Nav.Item>
              <Nav.Item>
                <Nav.Link eventKey="Five">Graphic Desining</Nav.Link>
              </Nav.Item>
              <Nav.Item>
                <Nav.Link eventKey="six">Search Engine Optimization</Nav.Link>
              </Nav.Item>
              <Nav.Item>
                <Nav.Link eventKey="Seven">Pay Per Click (PPC)</Nav.Link>
              </Nav.Item>
              <Nav.Item>
                <Nav.Link eventKey="eight">Digital Marketing </Nav.Link>
              </Nav.Item>
              <Nav.Item>
                <Nav.Link eventKey="nine"> Web Hosting </Nav.Link>
              </Nav.Item>
            </Nav>
          </Col>
          <Col sm={9}>
            <Tab.Content className="" style={{ height: "100%" }}>
              <Tab.Pane eventKey="first">
                <h2> Website Design</h2>
                <p>
                  " At Web Brain InfoTech, we provide comprehensive web design
                  solutions for a standout online presence. Our skilled team
                  ensures a unique, vibrant look for your website, enhancing its
                  visual impact and boosting customer acquisition. With our
                  responsive design, we make your brand future-ready, driving
                  increased traffic and conversions. Elevate your online
                  presence with our expertise. "
                </p>
                <div className="tab-images-text-parant">
                  <ul>
                    <li>
                      {" "}
                      <img src="https://www.webbraininfotech.com/image/file51.jpg" />
                    </li>

                    <li>
                      {" "}
                      <Link to=""> Static-Website-Design </Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src="https://www.webbraininfotech.com/image/file52.jpg" />
                    </li>
                    <li>
                      {" "}
                      <Link to=""> Dynamic-Website-Design </Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src="https://www.webbraininfotech.com/image/file54.jpg" />
                    </li>
                    <li>
                      {" "}
                      <Link to=""> eCommerce-Website-Design </Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src="https://www.webbraininfotech.com/image/file56.jpg" />
                    </li>
                    <li>
                      {" "}
                      <Link to=""> PSD TO ALL FORMATE</Link>{" "}
                    </li>
                  </ul>
                </div>
              </Tab.Pane>

              <Tab.Pane eventKey="second">
                <h2>Website Development</h2>
                <p>
                  " Web Brain InfoTech delivers top-notch, affordable web
                  development services tailored to client preferences. Whether
                  it's crafting visually appealing websites or optimizing for
                  search engines, we exceed expectations. Our innovative
                  developers seamlessly blend creative design and smart
                  technology, ensuring your website is future-ready for success
                  in the digital realm. "
                </p>
                <div className="tab-images-text-parant">
                  <ul>
                    <li>
                      {" "}
                      <img src="https://www.webbraininfotech.com/image/file41.jpg" />
                    </li>

                    <li>
                      {" "}
                      <Link to=""> eCommerce Web Development </Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src="https://www.webbraininfotech.com/image/file42.jpg" />
                    </li>
                    <li>
                      {" "}
                      <Link to=""> CMS Website Development </Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src="https://www.webbraininfotech.com/image/file43.jpg" />
                    </li>
                    <li>
                      {" "}
                      <Link to=""> Magento Web Development </Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src="https://www.webbraininfotech.com/image/file3.jpg" />
                    </li>
                    <li>
                      {" "}
                      <Link to=""> Open Source Solutions </Link>{" "}
                    </li>
                  </ul>

                  <ul>
                    <li>
                      {" "}
                      <img src="https://www.webbraininfotech.com/image/file53.jpg" />
                    </li>
                    <li>
                      {" "}
                      <Link to=""> Website Development </Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src="https://www.webbraininfotech.com/image/file33.jpg" />
                    </li>
                    <li>
                      {" "}
                      <Link to=""> PHP Web Developmen </Link>{" "}
                    </li>
                  </ul>
                </div>
              </Tab.Pane>

              <Tab.Pane eventKey="Thrid">
                <h2> Wordpress Development </h2>
                <p>
                  " Google is a household name, and we all use search engines
                  regularly. Your search query is what you type into the search
                  box, leading you to a Search Engine Results Page (SERP).
                  Search Engine Optimization (SEO) is crucial for top search
                  rankings, involving keyword tweaks, content optimization, and
                  link building. For effective SEO services in India, consider
                  affordable options to elevate your brand on search engine "
                </p>
                <div className="tab-images-text-parant">
                  <ul>
                    <li>
                      {" "}
                      <img src="https://images.unsplash.com/photo-1556155092-490a1ba16284?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8UHJlc2VuY2UlMjBBbmFseXNpc3xlbnwwfHwwfHx8MA%3D%3D" />
                    </li>

                    <li>
                      {" "}
                      <Link to=""> Local SEO</Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src="https://images.unsplash.com/photo-1556155092-490a1ba16284?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8UHJlc2VuY2UlMjBBbmFseXNpc3xlbnwwfHwwfHx8MA%3D%3D" />
                    </li>
                    <li>
                      {" "}
                      <Link to=""> Mobile SEO</Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src="https://images.unsplash.com/photo-1556155092-490a1ba16284?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8UHJlc2VuY2UlMjBBbmFseXNpc3xlbnwwfHwwfHx8MA%3D%3D" />
                    </li>
                    <li>
                      {" "}
                      <Link to=""> eCommerce-SEO</Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src="https://images.unsplash.com/photo-1556155092-490a1ba16284?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8UHJlc2VuY2UlMjBBbmFseXNpc3xlbnwwfHwwfHx8MA%3D%3D" />
                    </li>
                    <li>
                      {" "}
                      <Link to=""> Amazon-SEO</Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src="https://images.unsplash.com/photo-1556155092-490a1ba16284?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8UHJlc2VuY2UlMjBBbmFseXNpc3xlbnwwfHwwfHx8MA%3D%3D" />
                    </li>
                    <li>
                      {" "}
                      <Link to=""> Link-Building</Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src="https://images.unsplash.com/photo-1556155092-490a1ba16284?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8UHJlc2VuY2UlMjBBbmFseXNpc3xlbnwwfHwwfHx8MA%3D%3D" />
                    </li>
                    <li>
                      {" "}
                      <Link to=""> Content-Writing</Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src="https://images.unsplash.com/photo-1556155092-490a1ba16284?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8UHJlc2VuY2UlMjBBbmFseXNpc3xlbnwwfHwwfHx8MA%3D%3D" />
                    </li>
                    <li>
                      {" "}
                      <Link to=""> SEO-Reseller</Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src="https://images.unsplash.com/photo-1556155092-490a1ba16284?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8UHJlc2VuY2UlMjBBbmFseXNpc3xlbnwwfHwwfHx8MA%3D%3D" />
                    </li>
                    <li>
                      {" "}
                      <Link to=""> Panda-Recovery</Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src="https://images.unsplash.com/photo-1556155092-490a1ba16284?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8UHJlc2VuY2UlMjBBbmFseXNpc3xlbnwwfHwwfHx8MA%3D%3D" />
                    </li>
                    <li>
                      {" "}
                      <Link to=""> Online-Presence-Analysis</Link>{" "}
                    </li>
                  </ul>
                </div>
              </Tab.Pane>

              <Tab.Pane eventKey="Fourth">
                <h2> Mobile App Development </h2>
                <p>
                  " In the modern era, businesses have evolved beyond desktops
                  and laptops, embracing the widespread use of easily accessible
                  apps. With smartphones becoming ubiquitous, businesses can tap
                  into a vast customer base by transforming their ideas into
                  user-friendly mobile applications. The prevalence of
                  smartphones makes it an ideal platform to target potential
                  customers, regardless of the nature of the business or service
                  offered. Apps have become an essential tool for reaching and
                  engaging with a diverse audience, ensuring business success in
                  today's dynamic market. "
                </p>
                <div className="tab-images-text-parant">
                  <ul>
                    <li>
                      {" "}
                      <img src="https://www.webbraininfotech.com/image/file51.jpg" />
                    </li>

                    <li>
                      {" "}
                      <Link to=""> Mobile-Application</Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src="https://www.webbraininfotech.com/image/file52.jpg" />
                    </li>
                    <li>
                      {" "}
                      <Link to=""> Android-App-Development </Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src="https://www.webbraininfotech.com/image/file54.jpg" />
                    </li>
                    <li>
                      {" "}
                      <Link to=""> Windows-App-Development</Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src="https://www.webbraininfotech.com/image/file53.jpg" />
                    </li>
                    <li>
                      {" "}
                      <Link to="">iPhone-iOS-App </Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src="https://www.webbraininfotech.com/image/file56.jpg" />
                    </li>
                    <li>
                      {" "}
                      <Link to="">Blackberry-App</Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src="https://www.webbraininfotech.com/image/file57.jpg" />
                    </li>
                    <li>
                      {" "}
                      <Link to="">Web-App-Development</Link>{" "}
                    </li>
                  </ul>
                </div>
              </Tab.Pane>

              <Tab.Pane eventKey="Five">
                <h2> Graphic Desining</h2>
                <p>
                  " Google is a household name, and we all use search engines
                  regularly. Your search query is what you type into the search
                  box, leading you to a Search Engine Results Page (SERP).
                  Search Engine Optimization (SEO) is crucial for top search
                  rankings, involving keyword tweaks, content optimization, and
                  link building. For effective SEO services in India, consider
                  affordable options to elevate your brand on search engine "
                </p>
                <div className="tab-images-text-parant">
                  <ul>
                    <li>
                      {" "}
                      <img src="https://plus.unsplash.com/premium_photo-1680859126181-6f85456f864e?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8YmFubmVyfGVufDB8fDB8fHww" />
                    </li>

                    <li>
                      {" "}
                      <Link to="">  Banner Design </Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src="https://images.unsplash.com/photo-1533319417894-6fbb331e5513?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8bG9nb3xlbnwwfHwwfHx8MA%3D%3D" />
                    </li>
                    <li>
                      {" "}
                      <Link to=""> Logo Design</Link>{" "}
                    </li>
                  </ul>
                
               
                
      
                </div>
              </Tab.Pane>

              <Tab.Pane eventKey="six">
                <h2>Search Engine Optimization</h2>
                <p>
                  " Google is a widely recognized search engine, and whenever
                  you enter a query on platforms like Google, Yahoo, or Bing, it
                  generates results on a Search Engine Results Page (SERP).
                  Search Engine Optimization (SEO) is a crucial aspect of search
                  marketing, involving keyword optimization, content refinement,
                  and link building. To ensure your brand ranks high on search
                  engines, consider affordable SEO services in India, provided
                  by top SEO service providers in the country. "
                </p>
                <div className="tab-images-text-parant">
                  <ul>
                    <li>
                      {" "}
                      <img src="https://www.webbraininfotech.com/image/file1.jpg" />
                    </li>

                    <li>
                      {" "}
                      <Link to=""> Local SEO</Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src="https://www.webbraininfotech.com/image/file2.jpg" />
                    </li>
                    <li>
                      {" "}
                      <Link to=""> Mobile SEO</Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src=" https://www.webbraininfotech.com/image/file3.jpg" />
                    </li>
                    <li>
                      {" "}
                      <Link to=""> eCommerce-SEO</Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src=" https://www.webbraininfotech.com/image/file4.jpg" />
                    </li>
                    <li>
                      {" "}
                      <Link to=""> Amazon-SEO</Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src=" https://www.webbraininfotech.com/image/file5.jpg" />
                    </li>
                    <li>
                      {" "}
                      <Link to=""> Link-Building</Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src="https://www.webbraininfotech.com/image/file6.jpg" />
                    </li>
                    <li>
                      {" "}
                      <Link to=""> Content-Writing</Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src="https://www.webbraininfotech.com/image/file1.jpg" />
                    </li>
                    <li>
                      {" "}
                      <Link to=""> SEO-Reseller</Link>{" "}
                    </li>
                  </ul>
               
          
                </div>
              </Tab.Pane>

              <Tab.Pane eventKey="Seven">
                <h2>Pay Per Click (PPC) </h2>
                <p>
                  " Google is a household name, and we all use search engines
                  regularly. Your search query is what you type into the search
                  box, leading you to a Search Engine Results Page (SERP).
                  Search Engine Optimization (SEO) is crucial for top search
                  rankings, involving keyword tweaks, content optimization, and
                  link building. For effective SEO services in India, consider
                  affordable options to elevate your brand on search engine "
                </p>
                <div className="tab-images-text-parant">
                  <ul>
                    <li>
                      {" "}
                      <img src="https://www.webbraininfotech.com/image/file31.jpg" />
                    </li>

                    <li>
                      {" "}
                      <Link to=""> Conversion Rate Optimization</Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src="https://www.webbraininfotech.com/image/file32.jpg" />
                    </li>
                    <li>
                      {" "}
                      <Link to="">  PPC Reseller Services </Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src="https://www.webbraininfotech.com/image/file33.jpg" />
                    </li>
                    <li>
                      {" "}
                      <Link to="">  Display Advertising </Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src="https://www.webbraininfotech.com/image/file34.jpg" />
                    </li>
                    <li>
                      {" "}
                      <Link to="">  Affiliate Marketing </Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src="https://www.webbraininfotech.com/image/file38.jpg" />
                    </li>
                    <li>
                      {" "}
                      <Link to=""> Product Listing Ads</Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src="https://www.webbraininfotech.com/image/file72.jpg" />
                    </li>
                    <li>
                      {" "}
                      <Link to=""> Search Advertising  </Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src="https://www.webbraininfotech.com/image/file72.jpg" />
                    </li>
                    <li>
                      {" "}
                      <Link to=""> Email Marketing  </Link>{" "}
                    </li>
                  </ul>
             
               
                </div>
              </Tab.Pane>

              <Tab.Pane eventKey="eight">
                <h2>Digital Marketing</h2>
                <p>
                  " Google is a household name, and we all use search engines
                  regularly. Your search query is what you type into the search
                  box, leading you to a Search Engine Results Page (SERP).
                  Search Engine Optimization (SEO) is crucial for top search
                  rankings, involving keyword tweaks, content optimization, and
                  link building. For effective SEO services in India, consider
                  affordable options to elevate your brand on search engine "
                </p>
                <div className="tab-images-text-parant">
                  <ul>
                    <li>
                      {" "}
                      <img src="https://images.unsplash.com/photo-1596742578443-7682ef5251cd?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8R29vZ2xlJTIwUGVuYWx0eSUyMFJlY292ZXJ5JTIwU2VydmljZXxlbnwwfHwwfHx8MA%3D%3D" />
                    </li>

                    <li>
                      {" "}
                      <Link to="">Google Penalty Recovery Service</Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src="https://images.unsplash.com/photo-1484807352052-23338990c6c6?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8T25saW5lJTIwUmVwdXRhdGlvbiUyME1hbmFnZW1lbnR8ZW58MHx8MHx8fDA%3D" />
                    </li>
                    <li>
                      {" "}
                      <Link to="">  Online Reputation Management  </Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src="https://plus.unsplash.com/premium_photo-1661380904904-78010159f9f6?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8RGlnaXRhbCUyME1hcmtldGluZyUyMFNlcnZpY2VzfGVufDB8fDB8fHww" />
                    </li>
                    <li>
                      {" "}
                      <Link to="">Digital Marketing Services </Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src="https://plus.unsplash.com/premium_photo-1684611911419-0429f61be993?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8TGlua2VkSW4lMjBBZHZlcnRpc2luZ3xlbnwwfHwwfHx8MA%3D%3D" />
                    </li>
                    <li>
                      {" "}
                      <Link to="">   LinkedIn Advertising </Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src="https://images.unsplash.com/photo-1566458383719-239ca2d59a37?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8TGlua2VkSW4lMjBBZHZlcnRpc2luZ3xlbnwwfHwwfHx8MA%3D%3D" />
                    </li>
                    <li>
                      {" "}
                      <Link to="">  Facebook Advertising  </Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src="https://images.unsplash.com/photo-1535303311164-664fc9ec6532?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8VHdpdHRlciUyMEFkdmVydGlzaW5nfGVufDB8fDB8fHww" />
                    </li>
                    <li>
                      {" "}
                      <Link to=""> Twitter Advertising </Link>{" "}
                    </li>
                  </ul>
                  
                </div>
              </Tab.Pane>

              <Tab.Pane eventKey="nine">
                <h2> Web Hosting </h2>
                <p>
                  " Google is a household name, and we all use search engines
                  regularly. Your search query is what you type into the search
                  box, leading you to a Search Engine Results Page (SERP).
                  Search Engine Optimization (SEO) is crucial for top search
                  rankings, involving keyword tweaks, content optimization, and
                  link building. For effective SEO services in India, consider
                  affordable options to elevate your brand on search engine "
                </p>
                <div className="tab-images-text-parant">
                  <ul>
                    <li>
                      {" "}
                      <img src="https://images.unsplash.com/photo-1588675646184-f5b0b0b0b2de?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8RGVkaWNhdGVkJTIwU2VydmVyJTIwSG9zdGluZ3xlbnwwfHwwfHx8MA%3D%3D" />
                    </li>

                    <li>
                      {" "}
                      <Link to=""> Dedicated Server Hosting   </Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src="https://images.unsplash.com/photo-1529643554677-40cc9e0ecf5c?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8RG9tYWluJTIwTmFtZSUyMFJlZ2lzdHJhdGlvbnxlbnwwfHwwfHx8MA%3D%3D" />
                    </li>
                    <li>
                      {" "}
                      <Link to="">  Domain Name Registration</Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src="https://images.unsplash.com/photo-1675173655162-e7da9fdca0a1?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8UmVzZWxsZXIlMjBIb3N0aW5nfGVufDB8fDB8fHwwD" />
                    </li>
                    <li>
                      {" "}
                      <Link to="">  Reseller Hosting </Link>{" "}
                    </li>
                  </ul>
                  <ul>
                    <li>
                      {" "}
                      <img src="https://images.unsplash.com/photo-1491975474562-1f4e30bc9468?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8d2luZG93JTIwaG9zdGluZ3xlbnwwfHwwfHx8MA%3D%3D" />
                    </li>
                    <li>
                      {" "}
                      <Link to="">  Windows Hosting </Link>{" "}
                    </li>
                  </ul>
           
               
                </div>
              </Tab.Pane>
            </Tab.Content>
          </Col>
        </Row>
      </Tab.Container>
    </div>
  );
};

export default HomeTab;

import React from 'react'

const CaseStudy = () => {
  return (
    <div>
      
    </div>
  )
}

export default CaseStudy

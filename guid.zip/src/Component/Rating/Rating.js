import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faStar } from "@fortawesome/free-solid-svg-icons";
import { clutch } from "../../data/data";

import Carousel from "react-multi-carousel";
import "react-multi-carousel/lib/styles.css";

import "./Rating.css";

const Rating = () => {
  const responsive = {
    superLargeDesktop: {
      // the naming can be any, depends on you.

      breakpoint: { max: 4000, min: 3000 },
      items: 5,
    },
    desktop: {
      breakpoint: { max: 3000, min: 1024 },
      items: 3,
    },
    tablet: {
      breakpoint: { max: 1024, min: 464 },
      items: 3,   
    },
    mobile: {
      breakpoint: { max: 464, min: 0 },
      items: 3,
    },
  };

  return (
    <div>
      <section class="rating-parant">
        <div class="row text-center raing">
          {/* <div className="text-start container blue-line-bg">Our Rating Your Trust</div> */}
          <Carousel
            responsive={responsive}
            ssr={true} // means to render carousel on server-side.
            eyBoardControl={true}
            autoPlay={true}
            autoPlaySpeed={1500}
            infinite={true}
            transitionDuration={500}
          >
            {clutch.map((data) => (
              <div class="ra">
                <img
                  src={data.img}
                  class="rounded-circle shadow-1-strong  testimonialCompanyImg"
                  width="150"
                  alt=""
                  height="150"
                />

                <ul class="list-unstyled d-flex justify-content-center mb-0">
                  <li>
                    <FontAwesomeIcon icon={faStar} color="#ffc107" />
                  </li>
                  <li>
                    <FontAwesomeIcon icon={faStar} color="#ffc107" />
                  </li>
                  <li>
                    <FontAwesomeIcon icon={faStar} color="#ffc107" />
                  </li>
                  <li>
                    <FontAwesomeIcon icon={faStar} color="#ffc107" />
                  </li>
                  <li>
                    <FontAwesomeIcon icon={faStar} color="#ffc107" />
                  </li>
                </ul>
              </div>
            ))}
          </Carousel>
        </div>
      </section>
    </div>
  );
};

export default Rating;

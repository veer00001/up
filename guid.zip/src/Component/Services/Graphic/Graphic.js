import React from 'react'
import './Graphic.css'



const Graphic = () => {
  return (
    <div>
      Graphic
    </div>
  )
}

export default Graphic

import React from 'react'
import './Hosting.css'



const Hosting = () => {
  return (
    <div>
      
    </div>
  )
}

export default Hosting
